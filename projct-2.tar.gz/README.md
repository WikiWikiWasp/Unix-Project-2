# project 2 notes

myls must be compiled with the -lm flag

this is because it uses the math library for functions like log10

example compilation: gcc -o myls myls.c -lm
